/*
Copyright 2017 - 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at
    http://aws.amazon.com/apache2.0/
or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
*/

var express = require('express')
var router = express.Router()
var AWS = require('aws-sdk')
var uuid = require('node-uuid')

AWS.config.update({ region: process.env.REGION })

var dynamoDb = new AWS.DynamoDB.DocumentClient()


const MENU_TABLE_NAME = process.env.MENU_TABLE_NAME;
const ORDERS_TABLE_NAME = process.env.ORDERS_TABLE_NAME;
const RESTAURANTS_TABLE_NAME = process.env.RESTAURANTS_TABLE_NAME;

/****************************
 * Order management methods *
 ****************************/

router.post('/', function(req, res) {
    var order = {}
    if (!req.body.restaurant_id) {
        res.status(400).json({
            message: "Invalid restaurant id in order"
        }).end()
        return
    }
    if (!req.body.menu_items || req.body.menu_items.length == 0) {
        res.status(400).json({
            message: "You must order at least one item"
        }).end()
        return
    }

    order.restaurant_id = req.body.restaurant_id
    order.menu_items = req.body.menu_items
    order.id = uuid.v1()

    dynamoDb.put({
        TableName: ORDERS_TABLE_NAME,
        Item: order
    }, function(err, data) {
        if (err) {
            console.log(err)
            res.status(500).json({
                message: "Could not load menu item"
            }).end()
        } else {
            res.json(order)
        }
    })
})

router.get('/:orderId', function(req, res) {
    if (!req.params.orderId) {
        res.status(400).json({
            message: "Invalid order id"
        })
    }

    dynamoDb.get({
        TableName: ORDERS_TABLE_NAME,
        Key: {
            id: req.params.orderId
        }
    }, function(err, data) {
        if (err) {
            console.log(err)
            res.status(500).json({
                message: "Could not load order"
            }).end()
        } else {
            if (data['Item']) {
                res.json(data['Item'])
            } else {
                res.status(404).json({
                    message: "The order does not exist"
                })
            }
        }
    })
})

router.delete('/:orderId', function(req, res) {
    if (!req.params.orderId) {
        res.status(400).json({
            message: "Invalid order id"
        })
    }

    dynamoDb.delete({
        TableName: ORDERS_TABLE_NAME,
        Key: {
            id: req.params.orderId
        }
    }, function(err, data) {
        if (err) {
            console.log(err)
            res.status(500).json({
                message: "Could not delete order"
            }).end()
        } else {
            // if the item was deleted then we return a 204 - success but there's no content
            res.status(204).end()
        }
    })
})

module.exports = router