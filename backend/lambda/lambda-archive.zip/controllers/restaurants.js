/*
Copyright 2017 - 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at
    http://aws.amazon.com/apache2.0/
or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
*/

var express = require('express')
var router = express.Router()
var AWS = require('aws-sdk')

AWS.config.update({ region: process.env.REGION })

var dynamoDb = new AWS.DynamoDB.DocumentClient()


const MENU_TABLE_NAME = process.env.MENU_TABLE_NAME;
const ORDERS_TABLE_NAME = process.env.ORDERS_TABLE_NAME;
const RESTAURANTS_TABLE_NAME = process.env.RESTAURANTS_TABLE_NAME;

/**********************
 * Restaurant methods *
 **********************/

router.get('/', function(req, res) {
    // performs a DynamoDB Scan operation to extract all of the records in the table
    dynamoDb.scan({ TableName: RESTAURANTS_TABLE_NAME }, function(err, data) {
        if (err) {
            console.log(err)
            res.status(500).json({
                message: "Could not load restaurants"
            }).end()
        } else {
            var items = data['Items'];
            for (var i = 0; i < items.length; i++) {
                var item = items[i]
                if (item.name) { item.name = 'Test ' + item.name }
            }
            res.json(items)
        }
    })
})

router.get('/:restaurantId', function(req, res) {
    // Extracts a specific restaurant from the databsae. If an invalid restaurantId is sent
    // we will returna 400 status code. If the parameter value is valid but we cannot find
    // that restaurant in our database we return a 404
    if (!req.params.restaurantId) {
        res.status(400).json({
            message: "Invalid restaurant ID"
        }).end()
    }
    dynamoDb.get({
        TableName: RESTAURANTS_TABLE_NAME,
        Key: {
            id: req.params.restaurantId
        }
    }, function(err, data) {
        if (err) {
            console.log(err)
            res.status(500).json({
                message: "Could not load restaurant"
            }).end()
        } else {
            if (data['Item']) {
                res.json(data['Item'])
            } else {
                res.status(404).json({
                    message: "The restaurant does not exist"
                })
            }
        }
    })
})

/***************************
 * Restaurant menu methods *
 ***************************/

router.get('/:restaurantId/menu', function(req, res) {
    // lists all of the menu items for a restaurant.
    if (!req.params.restaurantId) {
        res.status(400).json({
            message: "Invalid restaurant ID"
        }).end()
    }
    dynamoDb.query({
        TableName: MENU_TABLE_NAME,
        KeyConditions: {
            restaurant_id: {
                ComparisonOperator: 'EQ',
                AttributeValueList: [ req.params.restaurantId]
            }
        }
    }, function(err, data) {
        if (err) {
            console.log(err)
            res.status(500).json({
                message: "Could not load restaurant menu"
            }).end()
        } else {
            res.json(data['Items'])
        }
    })
})

router.get('/:restaurantId/menu/:itemId', function(req, res) {
    // extracts the details of a specific menu item
    if (!req.params.restaurantId || !req.params.itemId) {
        res.status(400).json({
            message: "Invalid restaurant or item identifier"
        }).end()
    }
    dynamoDb.get({
        TableName: MENU_TABLE_NAME,
        Key: {
            restaurant_id: req.params.restaurantId,
            id: req.params.itemId
        }
    }, function(err, data) {
        if (err) {
            console.log(err)
            res.status(500).json({
                message: "Could not load menu item"
            }).end()
        } else {
            if (data['Item']) {
                res.json(data['Item'])
            } else {
                // return 404 if we couldn't find the menu item in the database
                res.status(404).json({
                    message: "The menu item does not exist"
                })
            }
        }
    })
})

module.exports = router